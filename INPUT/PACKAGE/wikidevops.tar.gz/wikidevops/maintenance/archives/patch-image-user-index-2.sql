CREATE INDEX /*i*/img_user_timestamp ON /*_*/image (img_user,img_timestamp);

-- field is deprecated and no longer updated as of 1.5
ALTER TABLE /*_*/site_stats DROP COLUMN ss_admins;
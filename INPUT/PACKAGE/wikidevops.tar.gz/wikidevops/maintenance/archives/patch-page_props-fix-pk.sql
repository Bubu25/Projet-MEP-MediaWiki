ALTER TABLE /*_*/page_props DROP KEY /*i*/pp_page_propname, ADD PRIMARY KEY (pp_page,pp_propname);
